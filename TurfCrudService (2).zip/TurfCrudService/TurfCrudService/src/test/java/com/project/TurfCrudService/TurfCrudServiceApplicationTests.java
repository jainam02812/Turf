package com.project.TurfCrudService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurfCrudServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
