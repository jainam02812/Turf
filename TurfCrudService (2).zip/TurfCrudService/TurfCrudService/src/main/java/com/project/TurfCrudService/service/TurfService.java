package com.project.TurfCrudService.service;

import org.springframework.stereotype.Service;

import com.project.TurfCrudService.entity.Turf;

@Service
public interface TurfService {

	Turf createTurf(Turf turf);

	String deleteTurf(Long id);

	String updateTurf(Long id, Turf turf);

	Turf getTurf(Long id);

}
